package br.com.senaisp.aula05;

public class ExemploComandoS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
