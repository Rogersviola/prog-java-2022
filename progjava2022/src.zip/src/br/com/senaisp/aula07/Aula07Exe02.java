package br.com.senaisp.aula07;

public class Aula07Exe02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int intValor = 100; intValor >= 1; intValor--)

			System.out.println(" O n�mero " + intValor);
 
	}

}
