package br.com.senaisp.aula07;

public class Aula07Exe03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" Os n�meros pares de 0 � 100 s�o ");
		for (int intValor = 0; intValor <= 200; intValor+=2)
            
			System.out.println(intValor);
 
	}

}
